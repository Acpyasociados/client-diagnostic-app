import axios from 'axios';

const BASE_URL = 'http://localhost:3000';

async function test() {
  console.log('🧪 PRUEBAS END-TO-END DEL BACKEND ACP\n');

  // PRUEBA 1: Health check
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('PRUEBA 1: Health Check');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  try {
    const res = await axios.get(`${BASE_URL}/api/health`);
    console.log('✅ Response:', res.data);
    console.log('Status:', res.status, '\n');
  } catch (e) {
    console.log('❌ Error:', e.message, '\n');
    return;
  }

  // PRUEBA 2: Validar cupón
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('PRUEBA 2: Validar Cupón TEST100');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  try {
    const res = await axios.post(`${BASE_URL}/api/validate-coupon`, {
      coupon: 'TEST100',
      plan: 'basico'
    });
    console.log('✅ Response:', JSON.stringify(res.data, null, 2));
    console.log('Validación:', res.data.valid ? '✅ VÁLIDO' : '❌ INVÁLIDO');
    console.log('Descuento:', res.data.discount_percentage + '%');
    console.log('Precio final:', '$' + res.data.final_price, '\n');
  } catch (e) {
    console.log('❌ Error:', e.message, '\n');
  }

  // PRUEBA 3: Validar cupón inválido
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('PRUEBA 3: Validar Cupón INVALIDO');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  try {
    const res = await axios.post(`${BASE_URL}/api/validate-coupon`, {
      coupon: 'INVALIDO',
      plan: 'basico'
    });
    console.log('Response:', res.data);
  } catch (e) {
    if (e.response && e.response.data) {
      console.log('✅ Respuesta correcta:', e.response.data);
      console.log('Error esperado:', e.response.data.error, '\n');
    }
  }

  // PRUEBA 4: Enviar lead (completo)
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('PRUEBA 4: Enviar Lead (Mercado Pago)');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  try {
    const res = await axios.post(`${BASE_URL}/api/submit-lead`, {
      name: 'Patricio Silva Valenzuela',
      email: 'patriciosilvavalenzuela@gmail.com',
      phone: '+56912345678',
      company: 'ACP y Asociados',
      sector: 'servicios_profesionales',
      monthly_sales: '5000000',
      margin: '50',
      active_clients: '100',
      top_costs: 'personal, arriendo, tecnología',
      main_channel: 'referidos',
      main_problem: 'escalabilidad',
      goal_6m: 'crecer 40%',
      plan: 'basico',
      discountPercentage: '100',
      finalPrice: '0'
    }, { timeout: 10000 });

    console.log('✅ Lead enviado exitosamente');
    console.log('Lead ID:', res.data.lead_id);
    console.log('Client Token:', res.data.client_token);
    console.log('Precio Final:', '$' + res.data.final_price);
    console.log('Checkout URL:', res.data.checkout_url ? '✅ Obtenida' : '❌ No obtenida');
    if (res.data.checkout_url) {
      console.log('  → ' + res.data.checkout_url.substring(0, 80) + '...\n');
    }
  } catch (e) {
    console.log('❌ Error:', e.message);
    if (e.response && e.response.data) {
      console.log('Detalles:', e.response.data);
    }
    console.log('');
  }

  // PRUEBA 5: Ver todos los leads
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('PRUEBA 5: Ver todos los Leads');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  try {
    const res = await axios.get(`${BASE_URL}/api/leads`);
    const count = res.data.leads ? res.data.leads.length : 0;
    console.log(`✅ Total de leads: ${count}`);
    if (count > 0) {
      const lead = res.data.leads[0];
      console.log('\nÚltimo lead:');
      console.log('  Nombre:', lead.name);
      console.log('  Email:', lead.email);
      console.log('  Empresa:', lead.company);
      console.log('  Plan:', lead.plan);
      console.log('  Status:', lead.status);
    }
    console.log('');
  } catch (e) {
    console.log('❌ Error:', e.message, '\n');
  }

  console.log('╔════════════════════════════════════════╗');
  console.log('║     ✅ PRUEBAS COMPLETADAS            ║');
  console.log('╚════════════════════════════════════════╝');
  process.exit(0);
}

test();
