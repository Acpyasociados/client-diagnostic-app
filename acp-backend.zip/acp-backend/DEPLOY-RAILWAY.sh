#!/bin/bash

# 🚀 SCRIPT DE DEPLOYMENT A RAILWAY
# Uso: bash DEPLOY-RAILWAY.sh

set -e  # Exit on error

echo "╔════════════════════════════════════════╗"
echo "║  🚀 ACP BACKEND - DEPLOYMENT RAILWAY  ║"
echo "╚════════════════════════════════════════╝"
echo ""

# PASO 1: Git setup
echo "📦 PASO 1: Configurar Git..."
if [ ! -d ".git" ]; then
    git init
    echo "✅ Repositorio Git inicializado"
else
    echo "✅ Git ya está configurado"
fi

# PASO 2: Agregar archivos
echo ""
echo "📝 PASO 2: Agregar archivos..."
git add -A
echo "✅ Archivos agregados"

# PASO 3: Commit
echo ""
echo "💾 PASO 3: Crear commit..."
git commit -m "Backend ACP operativo - Ready for Railway" || echo "✅ Sin cambios nuevos"
echo "✅ Commit creado"

# PASO 4: Mostrar status
echo ""
echo "📊 PASO 4: Status del repositorio..."
git log --oneline -1

# PASO 5: Instrucciones siguientes
echo ""
echo "╔════════════════════════════════════════╗"
echo "║  ✅ LISTO PARA RAILWAY                ║"
echo "╚════════════════════════════════════════╝"
echo ""
echo "PRÓXIMOS PASOS:"
echo ""
echo "1️⃣  Conecta a GitHub:"
echo "    git remote add origin https://github.com/TU_USUARIO/acp-backend.git"
echo "    git push -u origin main"
echo ""
echo "2️⃣  En Railway.app:"
echo "    • New Project → Deploy from GitHub"
echo "    • Selecciona 'acp-backend'"
echo "    • Agrega variables de entorno"
echo "    • Deploy automático ✅"
echo ""
echo "3️⃣  Obtén URL de Railway:"
echo "    Railway → Deployments → Domain"
echo ""
echo "4️⃣  Actualiza BACKEND_URL en index.html:"
echo '    const BACKEND_URL = "https://acp-backend-xyz.railway.app";'
echo ""
echo "¡LISTO! Tu backend estará operativo en 2-3 minutos 🎉"
