# 🚀 Desplegar en Railway

## Paso 1: Preparar repositorio Git
```bash
cd acp-backend
git init
git add .
git commit -m "Initial commit: ACP backend"
```

## Paso 2: Crear cuenta en Railway (5 minutos)
1. Ve a https://railway.app
2. Haz clic en "Start Project"
3. Conecta tu GitHub (o crea cuenta Railway directa)
4. Autoriza Railway para acceder a tus repos

## Paso 3: Crear proyecto en Railway
1. En Railway, haz clic en "New Project"
2. Selecciona "Deploy from GitHub"
3. Selecciona el repositorio `acp-backend`
4. Railway detectará que es Node.js automáticamente ✅

## Paso 4: Agregar variables de entorno
En la sección "Variables" de tu proyecto, agrega:

```
MERCADOPAGO_ACCESS_TOKEN = APP_USR-7215833646681882-042314-8a6b73129c1eaa7bad24e626d312c736-254339153

SENDGRID_API_KEY = re_HxvrhAzV_MVPawJuhabzjZY3DeZKE1Kt3

ADVISOR_EMAIL = asesor.pac@gmail.com

SITE_URL = https://tu-netlify-domain.netlify.app

NODE_ENV = production
```

Railway generará una URL automáticamente:
```
https://acp-backend-abc123.railway.app
```

## Paso 5: Actualizar frontend (index.html)
Cambiar todas las URLs de:
```javascript
fetch('/.netlify/functions/submit-lead', ...
fetch('/.netlify/functions/validate-coupon', ...
```

A:
```javascript
fetch('https://acp-backend-abc123.railway.app/api/submit-lead', ...
```

*(Reemplaza `acp-backend-abc123.railway.app` con tu URL real)*

## Paso 6: Probar
```bash
curl -X POST https://acp-backend-abc123.railway.app/api/health
# Respuesta: {"status":"healthy","timestamp":"..."}
```

---

## ⚠️ IMPORTANTE
- **NO commits los secrets** en el código
- Las variables están SEGURAS en Railway
- El servidor está LISTO cuando ves "Successfully deployed"

---

## Troubleshooting

### Verificar logs
En Railway → Deployments → click en tu último deploy → ver logs

### Reset rápido
```bash
git push
# Railway redeploys automáticamente
```

### Ver servidor corriendo localmente
```bash
npm install
node server.js
# Visita http://localhost:3000
```
